// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Collectible.h"
#include "StaminaCollectible.generated.h"

/**
 * 
 */
UCLASS()
class COMP217_LAB7_API AStaminaCollectible : public ACollectible
{
	GENERATED_BODY()
	
public:
	AStaminaCollectible();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Stamina")
	float StaminaAmount;
};
